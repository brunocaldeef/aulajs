let x = 1;
let soma = 0;

	while (x <= 10)
	{
		soma = soma + x;
		x++;
	}

	console.log ("A soma dos inteiros de 1 a 10 é: " + soma)