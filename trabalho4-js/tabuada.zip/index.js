let num = 0;
let x = 0;

num = prompt ("tabuada do")
function tabuada(num1, x) {
    return num1 * x;
}

for (let i = 0; i <= 10; i++) {
    console.log(num + " X " + x + ": " + tabuada(num, x));
    x++
    
}