const NUM_JOGADAS = 10;

let dado1 = 0;
let dado2 = 0;
let par = 0;
let impar = 0;

for (let x = 0; x <= NUM_JOGADAS; x++)
{
    dado1 =  Math.floor(Math.random() * 6 + 1);
		dado2 =  Math.floor(Math.random() * 6 + 1);

  let soma = dado1 + dado2;

    console.log("O resultado é " + soma + ", portando é");

    if ((soma%2)==0){
        console.log("Par");
        par++;
    }else{
        console.log("impar");
        impar++;
    }
}
console.log("Quantidade de pares= " + par);
console.log("Quantidade de impares= " + impar);

