let i = 0
var meuArray = [10, 9, 8, 7, 6, 5, 4, 3, 2, 1];
while (i <= 10) {
  let text = "O número é " + meuArray[i];
console.log(text); 
i++
}
