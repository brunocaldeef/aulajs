let i = 0
var meuArray = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100];
while (i <= 10) {
  let text = "O número é " + meuArray[i];
console.log(text); 
i++
}
