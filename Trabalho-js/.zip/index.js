const DEZ=10
var Num = 

if (Num >= DEZ){
  console.log ("True")
}else
{ console.log ("False")}