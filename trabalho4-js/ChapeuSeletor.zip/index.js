var nome = prompt ("Qual seu nome: ");
var qualidade = prompt ("Qual a sua principal qualidade");

function chapeuSeletor(nome, qualidade) {
    if (qualidade == 'Coragem' || qualidade =='Lealdade') {
        console.log("Parabéns " + nome + "!" + " Sua casa é a Grifinória!");
    } 
    else if (qualidade == 'Ambicioso' || qualidade =='Calculista' || qualidade =='Orgulhoso') {
        console.log("Parabéns " + nome + "!"  + " Sua casa é a Sonserina!");
    } 
    else if (qualidade =='Inteligente' || qualidade == 'Focado') {
        console.log("Parabéns " + nome + "!" + " Sua casa é a Corvinal!");
    } 
    else if (qualidade == 'Gentil'|| qualidade == 'Paciente') {
        console.log("Parabéns " + nome + "!" + " Sua casa é a Lufa-lufa!")
    }
}

console.log(chapeuSeletor(nome, qualidade));