const MEDIA = 70;
const LIMIT_FALTAS = 25;
const AULAS = 80;

let nome = "Bruno";
let nota1 = 60;
let nota2 = 70;
let nota3 = 80;
let num_faltas = 25;

let somaNota = nota1+nota2+nota3;
console.log ("soma das notas "+ somaNota);

let mediaAluno = somaNota/3;

let mediaAlunoFormat = mediaAluno.toFixed();
console.log("media do aluno "+ mediaAlunoFormat);

if (mediaAlunoFormat >= MEDIA) {
  console.log ("O aluno " + nome + " está aprovado" )
} else {
  console.log ("O aluno " + nome + " está reprovado")
}

let porcentagemFaltas = (num_faltas/AULAS)*100
console.log ("Porcentagem de faltas " + porcentagemFaltas + "%")

if(mediaAlunoFormat >= MEDIA && porcentagemFaltas < LIMIT_FALTAS) {
  console.log("O aluno " + nome + " está Aprovado");
} else if (mediaAlunoFormat >= MEDIA && porcentagemFaltas > LIMIT_FALTAS) {
  console.log("O aluno " + nome + " está Reprovado por Falta");
} else {
  console.log("O aluno " + nome + " está Reprovado por Média");
}