let num = 5;
let x = 0;

console.log("Tabuada do " + num);

do{
    console.log(num + " x " + x + " = " + num*x);
    x++;
}while(x <= 10);