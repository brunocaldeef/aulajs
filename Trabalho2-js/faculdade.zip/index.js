
const ALUNOS = 10;
let situacaoAluno = 0;
let aprovado = 0; 
let reprovado = 0;
for(let x = 0; x < ALUNOS; x++){
   situacaoAluno = prompt("Insirir resultado:");
      if (situacaoAluno ==1) {
         aprovado++;
   }else{
         reprovado++;
   }
}
if (aprovado >= 8) {
   console.log("Bonus to Instructor");
}
console.log("Alunos Aprovados: " + aprovado);
console.log("Alunos Reprovados: " + reprovado);