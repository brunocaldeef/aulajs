var Num1 = 
var Num2 = 

if (Num1 == Num2){
  console.log ("True")
}else{
  console.log("False")
}