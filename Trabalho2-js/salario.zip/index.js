const PORCENT30 = 30;
const PORCENT25 = 25;
const PORCENT20 = 20;
const PORCENT15 = 15;
const PORCENT10 = 10;

let salario = ;

let acrescimo30 = (salario * PORCENT30)/100;
let acrescimo25 = (salario * PORCENT25)/100;
let acrescimo20 = (salario * PORCENT20)/100;
let acrescimo15 = (salario * PORCENT15)/100;
let acrescimo10 = (salario * PORCENT10)/100;

let salario1 = (salario + acrescimo30)
let salario2 = (salario + acrescimo25)
let salario3 = (salario + acrescimo20)
let salario4 = (salario + acrescimo15)
let salario5 = (salario + acrescimo10)

if (salario <= 1045){
  console.log ("Salario atual= R$" + salario1)
}
else if (salario > 1045 && salario <= 1500){
  console.log ("Salario atual= R$" + salario2)
}
else if (salario > 1500 && salario <= 2600){
  console.log ("Salario atual= R$" + salario3)
}
else if(salario > 2600 && salario <= 3550){
  console.log ("Salario atual= R$" + salario4)
}
else if (salario > 3550){
  console.log ("Salario atual= R$" + salario5)
}