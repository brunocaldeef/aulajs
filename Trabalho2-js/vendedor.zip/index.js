const LUCRO50 = 45;
const LUCRO = 30;
const CINQUENTA = 50;

let valProduto = 45;

let acrescimo = (valProduto * LUCRO)/100;

let acrescimo50 = (valProduto * LUCRO50)/100;

let valProduto50 = (valProduto + acrescimo50)

let valProdutoMenor = (valProduto + acrescimo)

if (valProduto <= CINQUENTA){
  console.log ("Valor= R$" + valProduto50)
}else{
  console.log ("Valor=R$" + valProdutoMenor )
}


