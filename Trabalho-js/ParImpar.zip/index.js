var Inteiro = 

if (Inteiro %2 == 0){
  console.log ("True")
}else{console.log("False")}