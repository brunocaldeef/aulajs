let saqueDeposito = prompt("Digite sac para sacar ou dep para depositar")

let valor = prompt("Qual valor?")

function Banco (sacDep, val)
	{

let total = 1000;

switch(sacDep)
		{

case 'sac':
total = total - val;
break;
case 'dep':
total = total + val;
break;

		}
		return total;
	}

	alert ("Seu saldo atual é de R$" + Banco(saqueDeposito,parseInt(valor)))
