let x = 0;
let num1 = 1;
let num2 = 0;
let soma = 0;


do{
    console.log(soma);
    soma = num1 + num2;
    num1 = num2;
    num2 = soma;
	x++;
}while(x < 30);