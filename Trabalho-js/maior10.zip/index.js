const DEZ=10
var Num = 10

if (Num > DEZ){
  console.log ("True")
}else
{ console.log ("False")}